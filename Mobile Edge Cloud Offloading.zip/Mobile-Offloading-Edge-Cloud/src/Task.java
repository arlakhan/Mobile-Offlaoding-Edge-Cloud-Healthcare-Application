
public class Task {
    private String id;
    private double computationalLoad;
    private double dataSize;

    public Task(String id, double computationalLoad, double dataSize) {
        this.id = id;
        this.computationalLoad = computationalLoad;
        this.dataSize = dataSize;
    }

    public String getId() {
        return id;
    }

    public double getComputationalLoad() {
        return computationalLoad;
    }

    public double getDataSize() {
        return dataSize;
    }
}
