
public class EnergyCalculator {
    public static double calculateEnergy(MobileDevice device, Task task) {
        return task.getComputationalLoad() * device.getEnergyConsumption();
    }

    public static double calculateEnergy(EdgeServer server, Task task) {
        return task.getComputationalLoad() * server.getEnergyConsumption();
    }
}
