import java.util.Random;

public class EdgeServer {
    private String id;
    Random rand = new Random();
    int r1 = rand.nextInt(5);
    int r2 = rand.nextInt(9);
    public EdgeServer(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public double getProcessingPower() {
        return 199.2; // Example processing power
    }

    public double getEnergyConsumption() {
        return 49.9; // Example energy consumption rate
    }
}
