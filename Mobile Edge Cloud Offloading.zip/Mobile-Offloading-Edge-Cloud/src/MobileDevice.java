import java.util.Random;
public class MobileDevice {
    private String id;
    Random rand = new Random();
    int r1 = rand.nextInt(5);
    int r2 = rand.nextInt(9);
    public MobileDevice(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public double getProcessingPower() {
        return 199; // Example processing power
    }

    public double getEnergyConsumption() {
        return 50; // Example energy consumption rate
    }
}
