import java.util.Random;

public class OffloadingManager {
    private MobileDevice mobileDevice;
    private EdgeServer edgeServer;
    private SDNController sdnController;
    Random rand = new Random();
    int r1 = rand.nextInt(10);
    int communicationcost=7;
    public OffloadingManager(MobileDevice mobileDevice, EdgeServer edgeServer, SDNController sdnController) {
        this.mobileDevice = mobileDevice;
        this.edgeServer = edgeServer;
        this.sdnController = sdnController;
    }

    public void decideOffloading(Task task) {
        double mobileEnergy = EnergyCalculator.calculateEnergy(mobileDevice, task);
        double edgeEnergy = EnergyCalculator.calculateEnergy(edgeServer, task);

        double mobileTime = TimeCalculator.calculateTime(mobileDevice, task);
        double edgeTime = TimeCalculator.calculateTime(edgeServer, task);

        double mobileCost = CostCalculator.calculateCost(mobileDevice, task);
        double edgeCost = CostCalculator.calculateCost(edgeServer, task);
          // if (edgeEnergy > mobileEnergy && edgeTime > mobileTime && edgeCost > mobileCost) {
        if(mobileCost>edgeCost+communicationcost)
        {   System.out.println("Offloading task " + task.getId() + " to Edge Server " + edgeServer.getId());
           // System.out.println(mobileCost+"--"+edgeCost);
        } 
        
        else {
            System.out.println("Processing task " + task.getId() + " on Mobile Device " + mobileDevice.getId());
            //System.out.println(mobileEnergy);
           // System.out.println("-------");
            //System.out.println(edgeEnergy);
        }
    }
}
