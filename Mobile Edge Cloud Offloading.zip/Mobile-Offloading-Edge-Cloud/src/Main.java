
import java.util.List;
import java.util.Random;

public class Main {
	
	  static class Particle {
	        double[] position;  // Tasks local or offloaded
	        double[] velocity;  // speed of computing nodes
	        double[] bestPosition;  // best node for selection
	        double bestValue;  // optimal node for execution

	        public Particle(int dimension) {
	            position = new double[dimension];
	            velocity = new double[dimension];
	            bestPosition = new double[dimension];
	            bestValue = Double.MAX_VALUE;
	        }
	    }

	    // Objective function to minimize
	    public static double objectiveFunction(double[] position) {
	        double sum = 0.0;
	        for (double x : position) {
	            sum += x * x;  // Simple example: sphere function
	        }
	        return sum;
	    }
	
    public static void main(String[] args) {
    	TaskGenerator taskGenerator = new TaskGenerator("tasks.txt");
        List<Task> tasks = taskGenerator.generateTasks();
    	int swarmSize = 30;
        int dimension = 2;
        int maxIterations = 100;
        double inertia = 0.729;
        double cognitiveComponent = 1.49445;
        double socialComponent = 1.49445;
        double minPosition = -10;
        double maxPosition = 10;
        double minVelocity = -1;
        double maxVelocity = 1;

        Particle[] swarm = new Particle[swarmSize];
        Random random = new Random();

        // Initialize swarm
        for (int i = 0; i < swarmSize; i++) {
            swarm[i] = new Particle(dimension);
            for (int j = 0; j < dimension; j++) {
                swarm[i].position[j] = minPosition + (maxPosition - minPosition) * random.nextDouble();
                swarm[i].velocity[j] = minVelocity + (maxVelocity - minVelocity) * random.nextDouble();
                swarm[i].bestPosition[j] = swarm[i].position[j];
            }
            swarm[i].bestValue = objectiveFunction(swarm[i].position);
        }

        double[] globalBestPosition = new double[dimension];
        double globalBestValue = Double.MAX_VALUE;

        // Main PSO loop
        for (int t = 0; t < maxIterations; t++) {
            for (Particle particle : swarm) {
                double fitnessValue = objectiveFunction(particle.position);

                if (fitnessValue < particle.bestValue) {
                    particle.bestValue = fitnessValue;
                    System.arraycopy(particle.position, 0, particle.bestPosition, 0, dimension);
                }

                if (fitnessValue < globalBestValue) {
                    globalBestValue = fitnessValue;
                    System.arraycopy(particle.position, 0, globalBestPosition, 0, dimension);
                }
            }

            for (Particle particle : swarm) {
                for (int j = 0; j < dimension; j++) {
                    double r1 = random.nextDouble();
                    double r2 = random.nextDouble();

                    particle.velocity[j] = inertia * particle.velocity[j] +
                                           cognitiveComponent * r1 * (particle.bestPosition[j] - particle.position[j]) +
                                           socialComponent * r2 * (globalBestPosition[j] - particle.position[j]);

                    particle.velocity[j] = Math.max(minVelocity, Math.min(maxVelocity, particle.velocity[j]));

                    particle.position[j] += particle.velocity[j];
                    particle.position[j] = Math.max(minPosition, Math.min(maxPosition, particle.position[j]));
                }
            }

            System.out.println("Offloading Decision " + t + ": Optimal Offloading = " + globalBestValue);
        }

        System.out.println("Global Best Position: ");
        for (double value : globalBestPosition) {
            System.out.print(value + " ");
        }
        System.out.println("Scheduling all tasks on Local and Edge Server");
    		
    	MobileDevice mobileDevice = new MobileDevice("Local"+globalBestValue);
        EdgeServer edgeServer = new EdgeServer("EdgeServer"+globalBestValue);
        SDNController sdnController = new SDNController();
      
        OffloadingManager offloadingManager = new OffloadingManager(mobileDevice, edgeServer, sdnController);
        for (Task task : tasks) {
            offloadingManager.decideOffloading(task);
        }
     
        }
}





