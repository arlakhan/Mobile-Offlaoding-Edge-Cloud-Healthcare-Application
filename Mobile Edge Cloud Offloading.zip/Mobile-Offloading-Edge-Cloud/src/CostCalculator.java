
public class CostCalculator {
    public static double calculateCost(MobileDevice device, Task task) {
        return task.getComputationalLoad() * 0.01; // Example cost calculation
    }

    public static double calculateCost(EdgeServer server, Task task) {
        return task.getComputationalLoad() * 0.005; // Example cost calculation
    }
}
