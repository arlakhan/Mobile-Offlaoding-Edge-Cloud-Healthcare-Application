
public class TimeCalculator {
    public static double calculateTime(MobileDevice device, Task task) {
        return task.getComputationalLoad() / device.getProcessingPower();
    }

    public static double calculateTime(EdgeServer server, Task task) {
        return task.getComputationalLoad() / server.getProcessingPower();
    }
}
